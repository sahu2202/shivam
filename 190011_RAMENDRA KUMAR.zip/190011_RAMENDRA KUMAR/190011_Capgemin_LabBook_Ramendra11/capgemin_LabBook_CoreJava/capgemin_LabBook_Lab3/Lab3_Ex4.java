package capgemin_LabBook_Lab3;


public class Lab3_Ex4 {
	
	
	// Create a method that accepts a character array and
	//count the number of times each character is present in the array. 
	public static void Count(char[] ch){
		int len=ch.length;
		int count=0;
		for(int i=0;i<len;i++){
			count=0;
			for(int j=0;j<len;j++){
				if(ch[i]==ch[j]){
					count++;
				}
				
			}
			System.out.println(ch[i]+  "  Repeated "+  count);
		}
		
	}

	public static void main(String[] args) {
		char[] chare={'a','s','s','a','m','c','h','e','n','n','a','i'};
		Count(chare);
		

	}

}
