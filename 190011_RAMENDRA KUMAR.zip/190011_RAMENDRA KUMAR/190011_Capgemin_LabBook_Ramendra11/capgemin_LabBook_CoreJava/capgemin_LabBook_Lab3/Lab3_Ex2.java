package capgemin_LabBook_Lab3;
import java.lang.String;



public class Lab3_Ex2 {
		
		public static String[] string(String[] alphaSorting){
			int len= alphaSorting.length;
			String[] str=new String[len];
			int l1=(len/2)+1;
			int l2=len/2;
			String temp=" ";
			//String[] left= new String[len];
			//String[] right=new String[len];
			for(int i=0;i<len;i++){
				for(int j=i+1;j<len;j++){
					if(alphaSorting[i].compareTo(alphaSorting[j])>0){
						temp=alphaSorting[i];
						alphaSorting[i]=alphaSorting[j];
						alphaSorting[j]=temp;
						
					}
					// Create a method that can accept an array of String objects and sort in alphabetical order. 
					//The elements in the left half should be completely in uppercase and the elements in the right half should be completely in lower case. 
					//Return the resulting array. Note: If there are odd number of String objects, then (n/2) +1 elements should be in UPPPERCASE
				
					//for(int i=0;i<len;i++){
						if(len%2!=0){
							for(int i1=0;i1<l1;i1++){
								str[i1]= alphaSorting[i1].toLowerCase() ;
						}
							for(int i1=l1;i1<len;i1++){
								str[i1]=alphaSorting[i1].toUpperCase();
							}
					}else {
						for(int i1=0;i1<l2;i1++){
							str[i1]= alphaSorting[i1].toLowerCase() ;
					}
						for(int i1=l2;i1<len;i1++){
							str[i1]=alphaSorting[i1].toUpperCase();
						}
					}
					
				}
				//str[i]=alphaSorting[i];
			}
			for(int i=0;i<len;i++){
				System.out.println(str[i]);
			}	
				
				
		return str;	
			
		}
	public static void main(String[] args) {
		
		String[] str1={"ram","keshav","abhi","happy","heyy"};
		string(str1);
	}

}
