package capgemin_LabBook_Lab3;

import java.util.Arrays;

public class Lab3_Ex3 {
	public static int[] sortReverse(int[] arra) {
		int len = arra.length;
		int temp = 0;

		int[] reverse = new int[len];
		for (int i = 0; i < len; i++) {
			while ((arra[i] != 0)) {

				reverse[i] = reverse[i] * 10 + arra[i] % 10;
				arra[i] = arra[i] / 10;

			}

		}

		for (int i = 0; i < len; i++) {
			for (int j = i + 1; j < len; j++) {
				if (reverse[i] > reverse[j]) {
					temp = reverse[i];
					reverse[i] = reverse[j];
					reverse[j] = temp;
				}
			}
			// System.out.println(reverse[i]);
		}
		return reverse;

	}

	public static void main(String[] args) {
		// Create a method which accepts an integer array,
		// reverse the numbers in the array and returns the resulting array in
		// sorted order
		int[] arr = { 21, 32, 45, 65, 33, 54 };
		System.out.println(Arrays.toString(sortReverse(arr)));

	}
}
