package capgemin_LabBook_Lab3;

public class Lab3_Ex1 {
	public static int SecondLargest(int[] arry) {
		int len = arry.length;
		int temp = 0;
		int[] ary = new int[len];
		for (int i = 0; i < len; i++) {
			for (int j = i + 1; j < len; j++) {
				if (arry[i] > arry[j]) {
					temp = arry[i];
					arry[i] = arry[j];
					arry[j] = temp;
				}
			}
		}
	
	
	return arry[1];
	}

	
	
	
	

	public static void main(String[] args) {
		// Create a method which accepts an array of integer elements and return
		// the second smallest element in the array
		int[] array1={4,6,7,2,1,8,9,0};
		System.out.println(SecondLargest(array1)); 
	}

}
