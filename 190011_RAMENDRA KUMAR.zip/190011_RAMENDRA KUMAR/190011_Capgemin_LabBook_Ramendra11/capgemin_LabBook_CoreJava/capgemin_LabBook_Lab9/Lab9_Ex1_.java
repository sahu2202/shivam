package capgemin_LabBook_Lab9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Lab9_Ex1_ {
	
	public static List<String> sortby(HashMap<Integer, String> hm){
		
		//Create a list form element of HashMap
		//List<Map.Entry<Integer,String>> list= new LinkedList<Map.Entry<Integer, String>>(hm.entrySet());
		List<String> list=new ArrayList<String>(hm.values());
		
		//Sorting the list
		/*Collections.sort(list, new Comparator<Map.Entry<Integer,String>>() {
			public int compare(Map.Entry<Integer, String> o1, Map.Entry<Integer, String> o2){
				return(o1.getValue().compareTo(o2.getValue()));
			}*/
		
		//});
		Collections.sort(list);
		/*HashMap<Integer, String> temp= new LinkedHashMap<Integer, String>();
			for(Map.Entry<Integer,String> aa:list){
				temp.put(aa.getKey(),aa.getValue());
			}*/
			return list;
		}
		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> hashmap=new HashMap<>();
		hashmap.put(1, "Hello");
		hashmap.put(3, "Ramendra");
		hashmap.put(2, "Kumar");
		hashmap.put(5, "Noida");
		hashmap.put(4, "chennai");
		System.out.println(sortby(hashmap));
	}

}
