package capgemin_LabBook_Lab9;

import java.util.HashMap;
import java.util.Map;

public class Lab9_Ex2_Character {
	public static Map<Character,Integer> Count(char[] c){
		
		Map<Character, Integer> hashmap=new HashMap<Character, Integer>();
		
		for(char ch:c){
			if(hashmap.containsKey(ch)){
				hashmap.replace(ch, hashmap.get(ch)+1);
			}
			else hashmap.put(ch, 1);
		}
		return hashmap;
	}

	public static void main(String[] args) {
		char[] ch={'A','P','A','L','E'};
		Count(ch);
		System.out.println(Count(ch));
		
		
	}

}
