package capgemin_LabBook_Lab9;

import java.util.HashMap;
import java.util.Map;

public class Lab9_Ex3_Square {
	public static Map<Integer, Integer> getSquare(int[] arr){
		Map<Integer,Integer> hashmap=new HashMap<Integer, Integer>();
		for(int i=0;i<arr.length;i++){
			hashmap.put(arr[i], (arr[i]*arr[i]));
		}
		
		return hashmap;
	}
	public static void main(String[] args) {
		int[] arra={1,2,3,34,4,45,5,56};
		getSquare(arra);
		System.out.println(getSquare(arra));
	}

}
