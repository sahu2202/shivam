package capgemin_LabBook_Lab10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Lab10_P_1CopyDataThread extends Thread {

	File file;
	FileInputStream finput;
	FileOutputStream foutput;

	public Lab10_P_1CopyDataThread(FileInputStream f1, FileOutputStream f2) {
		super();
		this.finput = f1;
		this.foutput = f2;
	}

	@Override
	public void run() {
		int count = 1;
		int input = 0;
		try {
			while ((input = finput.read()) != -1) {
				System.out.println((char) input + "  " + count);
				if (count == 10) {
					System.out.println("10 characters are copied");
					count = 0;
					Thread.sleep(5000);
				}
				count++;
				foutput.write(input);
				

			}
		} catch (IOException e) {
			// TODO: handle exception
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}

/*
 * File file=new File("C:\\Users\\ramenkum\\Capgemini\\ReadMe.txt");
 * try(FileInputStream fInput=new FileInputStream(file)) { int input=0;
 * 
 * while((input=fInput.read())!=-1){
 * 
 * 
 * }
 * 
 * } catch (FileNotFoundException e) {
 * 
 * e.printStackTrace(); } catch (IOException e1) { e1.printStackTrace(); }
 * 
 */