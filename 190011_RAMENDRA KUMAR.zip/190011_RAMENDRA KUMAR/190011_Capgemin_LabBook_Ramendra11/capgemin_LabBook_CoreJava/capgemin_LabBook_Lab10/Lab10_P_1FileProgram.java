package capgemin_LabBook_Lab10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Lab10_P_1FileProgram {

	public static void main(String[] args) {
		File fileS = new File("C:\\files\\sorce.txt");
		File fileT = new File("C:\\files\\target.txt");
		try {
			FileInputStream fin = new FileInputStream(fileS);
			FileOutputStream fout = new FileOutputStream(fileT);
			Lab10_P_1CopyDataThread value = new Lab10_P_1CopyDataThread(fin, fout);
			value.start();
			
		} catch (FileNotFoundException e) {
			System.err.println("Not Found anything");
		}
		
	}

}
