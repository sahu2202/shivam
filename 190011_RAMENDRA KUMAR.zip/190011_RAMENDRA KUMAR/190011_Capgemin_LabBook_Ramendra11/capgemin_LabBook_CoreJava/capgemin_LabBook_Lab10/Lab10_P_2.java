package capgemin_LabBook_Lab10;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Lab10_P_2 extends TimerTask implements Runnable  {
	@Override
	public void run() {
		System.out.println("Task Started"+ new Date());
		completeTask();
		System.out.println("Task Ended"+ new Date());
		
	}
	public void completeTask(){
		try{
			Thread.sleep(20000);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		TimerTask timerTask=new Lab10_P_2();
		Timer timer=new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 10*1000);
		System.out.println("TimerTask started");
        //cancel after sometime
        try {
            Thread.sleep(120000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        timer.cancel();
        System.out.println("TimerTask cancelled");
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


		
			

	}


