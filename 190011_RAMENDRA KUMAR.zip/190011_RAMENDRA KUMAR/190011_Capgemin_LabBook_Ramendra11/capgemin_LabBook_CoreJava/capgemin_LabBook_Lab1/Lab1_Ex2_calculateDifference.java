//Calculate the difference 
package capgemin_LabBook_Lab1;

public class Lab1_Ex2_calculateDifference {
	
	public static int calculateDifference(int x){
		int sum;int m;
		m=x;
		if(((m*(m+1)*(2*m+1))/6)>((m*(m+1)/2)*(m*(m+1)/2))){
		sum=((m*(m+1)*(2*m+1))/6)-((m*(m+1)/2)*(m*(m+1)/2));
		}
		else{
			sum=((m*(m+1)/2)*(m*(m+1)/2))-((m*(m+1)*(2*m+1))/6);
		}
		return sum;
	}

	public static void main(String[] args) {
		int result;int y=10;
		result=calculateDifference(y);
		System.out.println(result);

	}

}
