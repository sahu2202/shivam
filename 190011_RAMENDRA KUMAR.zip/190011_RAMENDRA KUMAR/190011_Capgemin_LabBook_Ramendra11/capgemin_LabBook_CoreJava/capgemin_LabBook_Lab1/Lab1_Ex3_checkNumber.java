//Check if a number is an increasing number 
package capgemin_LabBook_Lab1;

public class Lab1_Ex3_checkNumber {
	public static boolean CheckNumber(int num) {
		String str = Integer.toString(num);
		int len = str.length();
		for (int i = 0; i < len - 1; i++) {
			if (str.charAt(i) > str.charAt(i + 1))
				return false;

		}

		return true;
	}

	public static void main(String[] args) {
		System.out.println(CheckNumber(16589));

	}

}
