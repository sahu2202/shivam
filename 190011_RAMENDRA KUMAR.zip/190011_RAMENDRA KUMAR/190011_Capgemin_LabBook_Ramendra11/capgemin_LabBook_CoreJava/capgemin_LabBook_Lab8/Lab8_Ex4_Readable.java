package capgemin_LabBook_Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.Scanner;

public class Lab8_Ex4_Readable {
	// Java program that reads on file name from the user,
	// then displays information about whether the file exists, whether the file
	// is readable,
	// whether the file is writable, the type of file and the length of the file
	// in bytes
	public static boolean FileExist(File file ) throws StreamCorruptedException {

		try (FileInputStream Finput = new FileInputStream(file);
				ObjectInputStream Oinput = new ObjectInputStream(Finput)) {
		if(file.exists());
			
			
		
			
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	public static boolean FileReadable(File file) {

		try (FileInputStream Finput = new FileInputStream(file);
				ObjectInputStream Oinput = new ObjectInputStream(Finput);) {
			
			Oinput.read();
			Oinput.close();

		}  catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean FileWriteable(File file) {

		try (FileOutputStream Finput = new FileOutputStream(file);
				ObjectOutputStream Oinput = new ObjectOutputStream(Finput);) {
			Oinput.writeUTF("");
			Oinput.close();

		}  catch(Exception e){
			return false;
		}
		return true;
	}
	public static void FileSize(File file) {

		try (FileInputStream Finput = new FileInputStream(file);
				ObjectInputStream Oinput = new ObjectInputStream(Finput);) {
			System.out.println(Finput.getChannel().size());

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public static void main(String[] args) throws StreamCorruptedException {
		File file; String FileName=null; int choice;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the file Address");
		FileName=scan.nextLine();
		file=new File(FileName);
		System.out.println("Press 1 To know File Exist or Not");
		System.out.println("Press 2 To know File is Readable");
		System.out.println("Press 3 To know File is Writable");
		System.out.println("Press 4 To know File Length");
		System.out.println("Press 5 To Exit ");
		choice=scan.nextInt();
		switch (choice) {
			case 1: FileExist(file);
			break;
			case 2: System.out.println(FileReadable(file)); 
			break;
			case 3: System.out.println(FileWriteable(file)); 
			break;
			case 4:FileSize( file) ;
			case 5: System.exit(0);
			default : System.out.println("Wrong Try Again");
			break;		
		}

	}

}
