package capgemin_LabBook_Lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_Tokenizer {

	public static void main(String[] args) {
		int n=0;
		int sum=0;
		String str="";
		Scanner scan=new Scanner(System.in);
		str=scan.nextLine();
		StringTokenizer st = new StringTokenizer(str, " ");
		while (st.hasMoreTokens()) {
            String temp = st.nextToken();
            n = Integer.parseInt(temp);
            System.out.println(n);
            sum = sum + n;
        }
        System.out.println("sum of the integers is: " + sum);
        scan.close();
    

	}

}
