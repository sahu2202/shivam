package capgemin_LabBook_Lab8;

import java.util.Scanner;

public class Lab8_Ex5_PositiveString {
	public static boolean PositiveString(String strs){
		int len= strs.length();
		String str="";
		char Ch;
		char[] ch= new char[len];
		for(int i=0;i<len;i++){
			ch[i]=strs.charAt(i);
		}
		for(int i=0;i<len;i++){
			for(int j=i+1;j<len;j++){
				if(ch[i]>ch[j]){
					Ch=ch[i];
					ch[i]=ch[j];
					ch[j]=Ch;
				}
			}
		}
		
		for(int i=0;i<len;i++){
			str=str+ch[i];
		}
		
		if(str.equalsIgnoreCase(strs))
			return true;
			else
				return false;
		//System.out.println(str);
	}

	public static void main(String[] args) {
		String str=new String();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a Word ");
		str=scan.nextLine();
		if(PositiveString(str)==true)
			System.out.println("Positive String");
		else
			System.out.println("Not Positive String");
		

	}

}
