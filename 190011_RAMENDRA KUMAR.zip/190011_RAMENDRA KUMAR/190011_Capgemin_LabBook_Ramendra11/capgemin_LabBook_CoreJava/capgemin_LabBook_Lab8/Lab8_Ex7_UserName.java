package capgemin_LabBook_Lab8;

public class Lab8_Ex7_UserName {
	private String Username;
		
	public void setUsername(String username) {
		String str="";String Str1="_job";
		str=username;
		str=str+Str1;
		this.Username=str;
	}

	public String getUsername() {
		return Username;
	}
	public boolean Validation(){
		String string=getUsername();
		int len=string.length();
		int count=0;
		char[] ch= new char[len];
		for(int i=0;i<len;i++){
			ch[i]=string.charAt(i);
		}
		for(int i=0;i<len;i++){
			if(ch[i]!='_'){
				count++;
			}
			
		}
		if(count>=7){
			return true;
		} else
			return false;
	}
	

	public static void main(String[] args) {
		
		Lab8_Ex7_UserName b1=new Lab8_Ex7_UserName();
		b1.setUsername("Ramendra");
		System.out.println(b1.Validation());
		System.out.println(b1.getUsername());

	}

}
