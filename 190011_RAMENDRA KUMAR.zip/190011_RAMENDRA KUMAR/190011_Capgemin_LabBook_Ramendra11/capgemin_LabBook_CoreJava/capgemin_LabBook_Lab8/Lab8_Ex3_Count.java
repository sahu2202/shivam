package capgemin_LabBook_Lab8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab8_Ex3_Count {
	//A Java program that displays the number of characters, lines and words in a text
	
	public static void CountFile(File file){
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		InputStreamReader InputR= new InputStreamReader(fileInput);
		BufferedReader Bread= new BufferedReader(InputR);
		String line;
		int CharacterCount=0;
		int countWord=0;
		int countsentance=0;
		try {
			while((line=Bread.readLine())!=null){
				if(!(line.equals(""))){
					CharacterCount +=line.length();
					String[] wList=line.split("\\s+");
					countWord+=wList.length;
					String[] sList=line.split("[!?.:]");
					countsentance+= sList.length;
				}
				
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		System.out.println("Number of Character in File:"+"  "+CharacterCount);
		System.out.println("Number of Word in File:"+"  "+countWord);
		System.out.println("Number of Sentance in File:"+"  "+countsentance);
	}

	public static void main(String[] args) {
		
		File file = new File("C:\\Users\\ramenkum\\Capgemini\\ReadMe.txt");
		
		CountFile(file);

	}

}
