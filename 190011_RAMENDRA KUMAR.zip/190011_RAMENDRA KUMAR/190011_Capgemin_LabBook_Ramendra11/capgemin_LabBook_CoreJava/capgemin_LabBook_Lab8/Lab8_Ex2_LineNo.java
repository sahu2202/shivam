package capgemin_LabBook_Lab8;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Lab8_Ex2_LineNo {
	public static void LineNoFile(File file){
	
	LineNumberReader L1=null;
	
	
	try (FileInputStream fileInput = new FileInputStream(file)) {
		L1=new LineNumberReader(new FileReader(file));
		
		
		String Line=null;
		while ((Line=L1.readLine()) !=null) {
			System.out.println(L1.getLineNumber()+"  "+Line);
			
		}
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}

}

	public static void main(String[] args) {
		File file = new File("C:\\Users\\ramenkum\\Capgemini\\ReadMe.txt");
		LineNoFile(file);

	}

}
