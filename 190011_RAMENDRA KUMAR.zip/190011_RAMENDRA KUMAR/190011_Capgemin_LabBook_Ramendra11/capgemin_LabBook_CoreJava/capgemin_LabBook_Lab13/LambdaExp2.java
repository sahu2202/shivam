package capgemin_LabBook_Lab13;
interface StringVal{
	public String Exp(String str);
}
public class LambdaExp2 {

	public static void main(String[] args) {
		StringVal val=(str)->{
			int len=str.length();
			String stri="";
			for(int i=0;i<len;i++){
				char st=str.charAt(i);
				stri=stri+st+" ";
			}
			return stri;
		};
		String strii="ABC";
		System.out.println( val.Exp(strii));
	}

}
