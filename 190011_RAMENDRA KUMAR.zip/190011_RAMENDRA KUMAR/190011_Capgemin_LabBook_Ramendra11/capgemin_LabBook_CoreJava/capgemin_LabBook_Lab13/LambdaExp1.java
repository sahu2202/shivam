package capgemin_LabBook_Lab13;


// lambda expression which accepts x and y numbers and return xy
interface Expression{
	 Double Res(int x,int y);
		
	
}
public class LambdaExp1 {
	
	public static void main(String[] args) {
		
		Expression expression = (x,y) ->{
			return Math.pow(x, y);
		};
		
		System.out.println(expression.Res(2, 3)); 

	}

}
