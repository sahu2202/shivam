package capgemin_LabBook_Lab13;
//Write a method that uses lambda expression to accept username and password and return true or false

interface TrueF{
	public boolean UserPW(String UserName, String Password); 
}
public class LambdaExp3 {

	public static void main(String[] args) {
		TrueF Tf=(username,password)->{
			if((username=="Admin")&&(password=="12345678")){
				return true;
			}
			
			else
			return false;
			
		};
		
		String UN="Admin";String PS="1234";
		
		System.out.println(Tf.UserPW(UN,PS)); 

	}

}
