package capgemin_LabBook_Lab13;

public class LambdaExp4Class {

	private String Name;
	private String city;
	private String phoneNo;
	
	
	public LambdaExp4Class() {
		Name=null;
		city=null;
		phoneNo=null;
	}


	public LambdaExp4Class(String name, String city, String phoneNo) {
		super();
		Name = name;
		this.city = city;
		this.phoneNo = phoneNo;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	@Override
	public String toString() {
		return "LambdaExp4Class [Name=" + Name + ", city=" + city + ", phoneNo=" + phoneNo + "]";
	}
	
}
