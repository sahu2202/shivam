package capgemin_LabBook_Lab13;

import java.util.function.Supplier;

public class LambdaExp4Main {

	public static void main(String[] args) {
		Supplier<LambdaExp4Class> list= LambdaExp4Class :: new;
		
		LambdaExp4Class a1=list.get();
		a1.setName("Ramendra");
		a1.setCity("Chennai");
		a1.setPhoneNo("7290999");
		System.out.println(a1);
		LambdaExp4Class a2=list.get();
		a2.setName("Vijay");
		a2.setCity("Chennai");
		a2.setPhoneNo("12345");
		System.out.println(a2);
		

	}

}
