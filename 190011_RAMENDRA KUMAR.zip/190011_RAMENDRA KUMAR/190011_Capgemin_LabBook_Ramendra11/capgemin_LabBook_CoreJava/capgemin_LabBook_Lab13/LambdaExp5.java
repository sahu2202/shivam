package capgemin_LabBook_Lab13;
	// Write a method to calculate factorial of a number. Test this method using method reference feature
interface Result{
	public int Factorial(int num);
}
public class LambdaExp5 {

	public static void main(String[] args) {
		Result r=(num)-> {
			int res=1;
			for(int i=1;i<=num;i++){
				res=res*i;
			}
			return res;
		};
		
		System.out.println(r.Factorial(5)); 
	}

}
