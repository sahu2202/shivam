package capgemin_LabBook_Lab4;

public class Lab4_Ex1 {
	
	public static int Cube(int any){
		int result=0;
		int temp=0;
		//reverse[i] = reverse[i] * 10 + arra[i] % 10;
		//arra[i] = arra[i] / 10;
		while(any!=0){
			temp=any%10;
			
			result=result+(temp*temp*temp);
			any=any/10;
			
		}
		return result;
		
	}

	public static void main(String[] args) {
		int x=47;
		System.out.println(Cube(x)); 

	}

}
