package com.cg.eis.service;

import com.cg.eis.bean.Employe;

public interface EmployeeServiceInterface {

	public void getUser(Employe emp);

	public String FindInsuranceScheme(int empId);

	public Employe getDetails(int id);

}
