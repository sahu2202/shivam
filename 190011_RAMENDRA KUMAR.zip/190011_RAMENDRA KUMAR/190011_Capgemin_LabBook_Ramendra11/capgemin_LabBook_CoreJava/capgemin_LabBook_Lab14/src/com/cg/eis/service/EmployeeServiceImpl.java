package com.cg.eis.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employe;

public class EmployeeServiceImpl implements EmployeeServiceInterface {

	private Map<Integer, Employe> employ = null;

	public EmployeeServiceImpl() {
		employ = new HashMap<Integer, Employe>();
	}

	@Override
	public void getUser(Employe emp) {
		employ.put(emp.getEmpId(), emp);
	}

	
	@Override
	public String FindInsuranceScheme(int empId) {
		if(employ.containsKey(empId))
			return employ.get(empId).getInsuranceScheme();
		return null;
	}

	@Override
	public Employe getDetails(int id) {
		if(employ.containsKey(id))
			return employ.get(id);
		return null;
	}

}
