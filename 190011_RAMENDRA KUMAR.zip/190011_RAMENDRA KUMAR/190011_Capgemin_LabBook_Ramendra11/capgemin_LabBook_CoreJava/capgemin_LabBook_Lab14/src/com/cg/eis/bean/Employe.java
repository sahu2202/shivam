package com.cg.eis.bean;

public class Employe {

	private static int EMPCOUNT=1;

	private int empId;
	private String empName;
	private double salary;
	private String designation;
	private String insuranceScheme;

	public Employe() {
		super();
		this.setEmpId();
	}

	public Employe(String empName, double salary, String designation) {
		super();
		this.setEmpId();
		this.setEmpName(empName);
		this.setSalary(salary);
		this.setDesignation(designation);
		this.setInsuranceScheme();
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId() {
		this.empId = EMPCOUNT++;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme() {
		if (this.salary > 5000 && this.salary < 20000 && this.designation.equalsIgnoreCase("System Associate"))
			this.insuranceScheme = "Scheme C";
		if (this.salary >= 20000 && this.salary < 40000 && this.designation.equalsIgnoreCase("Programmer"))
			this.insuranceScheme = "Scheme B";
		if (this.salary >= 40000 && this.designation.equalsIgnoreCase("Manager"))
			this.insuranceScheme = "Scheme A";
		if (this.salary < 5000 && this.designation.equalsIgnoreCase("Clerk"))
			this.insuranceScheme = "No Scheme";
	}
	
	
}
