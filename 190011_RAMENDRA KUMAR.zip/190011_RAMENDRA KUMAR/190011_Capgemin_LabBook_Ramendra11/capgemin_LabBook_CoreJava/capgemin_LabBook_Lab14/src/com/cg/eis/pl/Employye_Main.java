package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employe;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.EmployeeServiceInterface;

public class Employye_Main {

	static Scanner scanner = new Scanner(System.in);

	public static String getInput(String message) {
		System.out.println(message);
		String input = scanner.nextLine();
		return input;
	}

	public static void main(String[] args) {
		EmployeeServiceInterface employeeService = new EmployeeServiceImpl();
		int choice = 0;
		do {
			System.out.println("Employee application");
			System.out.println("1.Register user");
			System.out.println("2.Find Insurance Scheme");
			System.out.println("3.Employee Details");
			System.out.println("Enter your choice");
			choice = Integer.parseInt(scanner.nextLine());
			switch (choice) {
			case 1:
				String name = getInput("Enter employee name :");
				double salary = Double.parseDouble(getInput("salary :"));
				String designation = getInput("Designation :");
				Employe employe = new Employe(name, salary, designation);
				employeeService.getUser(employe);
				System.out.println("Employee created sucessfully with id :" + employe.getEmpId());
				break;
			case 2:
				int id = Integer.parseInt(getInput("Employee Id"));
				String scheme = employeeService.FindInsuranceScheme(id);
				if (scheme != null)
					System.out.println(scheme);
				else
					System.out.println("Employee not Found");
				break;
			case 3:
				int empId = Integer.parseInt(getInput("Employee Id"));
				Employe emp1 = employeeService.getDetails(empId);
				if (emp1 != null)
					System.out.println("\nEmployee Details : \nEmployee Name : " + emp1.getEmpName()
							+ "\nEmployee ID : " + emp1.getEmpId() + "\nSalary : " + emp1.getSalary()
							+ "\nDesignation : " + emp1.getDesignation() + "\nInsurance Scheme : "
							+ emp1.getInsuranceScheme() + "\n");
				else
					System.out.println("Employee not Found");
				break;
			}
		} while (choice != 4);
	}
}
