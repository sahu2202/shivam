package capgemin_LabBook_Lab5;

public class Lab5_Ex2_Fibonacci {
	/*  The Fibonacci sequence is defined by the following rule. 
	 * The first 2 values in the sequence are 1, 1. 
	 * Every subsequent value is the sum of the 2 values preceding it. 
	 * Write a Java program that uses both recursive and nonrecursive functions 
	 * to print the nth value of the Fibonacci sequence? */

	public static int NonRecursiveFibonacci(int x){
		if((x==1)||(x==0)){
			return 0;
		} else{
		int first=1,second=1,temp=0;
		for(int i=3;i<=x;i++){
			temp=first+second;
			first=second;
			second=temp;
			
		}
		return temp;
		}
		
	}
	
	public static int RecursiveFibonacci(int x){
		if((x==1)||(x==0)){
			return 1;
		}
		else{
			return RecursiveFibonacci(x-1)+RecursiveFibonacci(x-2);
		}
	}
	public static void main(String[] args) {
		
		System.out.println(NonRecursiveFibonacci(7)); 
		System.out.println(RecursiveFibonacci(3));
		
	}

}
