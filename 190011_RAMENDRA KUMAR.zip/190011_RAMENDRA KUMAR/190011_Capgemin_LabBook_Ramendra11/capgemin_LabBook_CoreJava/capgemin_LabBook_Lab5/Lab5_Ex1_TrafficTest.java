package capgemin_LabBook_Lab5;

public class Lab5_Ex1_TrafficTest {

	public static void main(String[] args) {
		Lab5_Ex1_Abutton f=new Lab5_Ex1_Abutton();
		f.setBounds(100, 100, 300, 300);
		f.setTitle("Traffic Light");
		f.setVisible(true);

	}

}
