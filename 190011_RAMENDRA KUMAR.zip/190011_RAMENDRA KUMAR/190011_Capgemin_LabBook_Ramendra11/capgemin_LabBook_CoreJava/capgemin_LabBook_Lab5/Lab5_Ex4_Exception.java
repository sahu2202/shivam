package capgemin_LabBook_Lab5;

public class Lab5_Ex4_Exception extends Exception {
	public Lab5_Ex4_Exception(String Message){
		super(Message);
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage()+"Do not leave First Name or Last name Empty";
	}
	}


