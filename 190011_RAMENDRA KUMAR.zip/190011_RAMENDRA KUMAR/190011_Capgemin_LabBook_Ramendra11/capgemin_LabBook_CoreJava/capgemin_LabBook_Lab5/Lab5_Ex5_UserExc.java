package capgemin_LabBook_Lab5;

public class Lab5_Ex5_UserExc extends Exception {
	

	
		public Lab5_Ex5_UserExc(String Message){
			super(Message);
		}
		
		@Override
		public String getMessage() {
			// TODO Auto-generated method stub
			return super.getMessage()+"age should be greater than 15";
		}
		}





