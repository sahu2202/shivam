package capgemin_LabBook_Lab5;

public class Lab5_Ex6_EmployeeException extends Exception{
	public Lab5_Ex6_EmployeeException(String Message){
		super(Message);
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage()+"age should be greater than 15";
	}

}
