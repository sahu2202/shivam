package capgemin_LabBook_Lab5;



public class Lab5_Ex5_age {
	private int age;
	

	public void setAge(int age)throws Lab5_Ex5_UserExc {
		if(age<15)
			throw new Lab5_Ex5_UserExc("Age must be Greater than 15");
		this.age = age;
	}


	public static void main(String[] args) {
		
		Lab5_Ex5_age b1=new Lab5_Ex5_age();
		
		try {
			b1.setAge(10);
		} catch (Lab5_Ex5_UserExc e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
