package capgemin_LabBook_Lab5;

public class Lab5_Ex4_UserDefinExc {

	public static void main(String[] args) {
		Lab5_Ex4_Employee E1=new Lab5_Ex4_Employee();
		
		try {
			E1.setFname("");
		} catch (Lab5_Ex4_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			E1.setLname("");
		} catch (Lab5_Ex4_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		
		
		
	}

}
