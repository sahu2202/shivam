package capgemin_LabBook_Lab5;

public class Lab5_Ex3_Integer {
	
	/* Write a Java program that 
	 * prompts the user for an integer and then prints out 
	 * all the prime numbers up to that Integer? 
	 * */
	public static void Prime_Number(int x){
		int count=0;
		if(x==0){
			System.out.println("Enter Valid Number");
		}
		
			
			
			else{
				for(int i=1;i<=x;i++){
					count=0;
					for(int j=1;j<=x;j++){
						if(i%j==0)
							count++;
						
						
					}
					if(count==2)
						System.out.println(i);
				}
			}
	}
	public static void main(String[] args) {
		Prime_Number(10);
		
	}
}
