package capgemin_LabBook_Lab5;

public class Lab5_Ex4_Employee {
	private String Fname;
	private String Lname;
	public Lab5_Ex4_Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Lab5_Ex4_Employee(String fname, String lname) {
		super();
		try {
			setFname(fname);
		} catch (Lab5_Ex4_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Fname = fname;
		try {
			setLname(lname);
		} catch (Lab5_Ex4_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Lname = lname;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) throws Lab5_Ex4_Exception {
		if(fname==null||fname=="")
			throw new Lab5_Ex4_Exception("First name cannot be null or left blank");
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname)throws Lab5_Ex4_Exception {
		if(lname==null||lname=="") throw new Lab5_Ex4_Exception("Last name cannot be null or left blank");
		Lname = lname;
	}
	

}
