package capgemin_LabBook_Lab5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;

import javax.swing.JRadioButton;

/*Write a java program that simulates a traffic light. 
 * The program lets the user select one of three lights: red, yellow, or green with radio buttons. 
 * On entering the choice, an appropriate message with �stop� or �ready� or �go� should appear 
 * in the console .Initially there is no message shown. 
*/

public class Lab5_Ex1_Abutton extends JFrame  {

	JRadioButton J1;
	JRadioButton J2;
	JRadioButton J3;
	ButtonGroup B1;

	JLabel L1;

	public Lab5_Ex1_Abutton(){
		this.setLayout(null);
		 J1=new JRadioButton();
		ActionListener a = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JRadioButton j = (JRadioButton)e.getSource();
				System.out.println(j.getActionCommand());
				
			}
		};
					
		 J1.setText("RED");
		 System.out.println();
		 J1.addActionListener(a);
		 J2=new JRadioButton();
		 J2.setText("YELLOW");
		 J2.addActionListener(a);
		 J3=new JRadioButton();
		 J3.setText("GREEN");
		 J3.addActionListener(a);
		
		L1=new JLabel("Traffic Light");
		L1.setBounds(5, 50, 100, 100);
		
		B1=new ButtonGroup();
		J1.setBounds(5, 10, 90, 50);
		J2.setBounds(5, 40, 90, 50);
		J3.setBounds(5, 70, 90, 50);
		this.add(J1);
		this.add(J2);
		this.add(J3);
		this.add(L1);
		
		B1.add(J1);
		B1.add(J2);
		B1.add(J3);
		
		
	}

}
