package capgemin_LabBook_Lab5;

public class Lab5_Ex6_Employee {
	private float salary;
	

	public void setSalary(float salary) throws Lab5_Ex6_EmployeeException {
		if(salary<3000) 
			throw new Lab5_Ex6_EmployeeException("Salary Must be Greater than 3000");
		this.salary = salary;
	}


	public static void main(String[] args) {
		Lab5_Ex6_Employee e1=new Lab5_Ex6_Employee();
	
		try {
			e1.setSalary(2000);
		} catch (Lab5_Ex6_EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
