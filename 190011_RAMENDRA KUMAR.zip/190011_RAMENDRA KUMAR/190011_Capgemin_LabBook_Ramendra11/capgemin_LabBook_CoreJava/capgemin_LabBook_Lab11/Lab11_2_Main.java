package capgemin_LabBook_Lab11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutionException;

public class Lab11_2_Main {

	public static void main(String[] args) {
		File fileS = new File("C:\\files\\sorce.txt");
		File fileT = new File("C:\\files\\target.txt");
		
		try {
			FileInputStream fin = new FileInputStream(fileS);
			FileOutputStream fout = new FileOutputStream(fileT);
			Lab11_2 value = new Lab11_2(fin, fout);
			try {
				System.out.println(value.future.get()); 
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} catch (FileNotFoundException e) {
			System.err.println("Not Found anything");
		}
		
		Lab11_2 value = null;
		value.executorService.shutdown();

	}

}
