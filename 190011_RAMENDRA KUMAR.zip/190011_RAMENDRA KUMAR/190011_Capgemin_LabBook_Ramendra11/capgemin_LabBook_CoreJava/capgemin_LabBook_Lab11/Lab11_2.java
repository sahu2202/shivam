package capgemin_LabBook_Lab11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Lab11_2 {
ExecutorService executorService=Executors.newSingleThreadExecutor();
	

	File file;
	FileInputStream finput;
	FileOutputStream foutput;

	public Lab11_2(FileInputStream f1, FileOutputStream f2) {
		super();
		this.finput = f1;
		this.foutput = f2;
	}
	Callable<String> callable=new Callable<String>() {
		@Override
		public String call() throws Exception {
			int count = 1;
			int input = 0;
			try {
				while ((input = finput.read()) != -1) {
					System.out.println((char) input + "  " + count);
					if (count == 10) {
						System.out.println("10 characters are copied");
						count = 0;
						Thread.sleep(5000);
					}
					count++;
					foutput.write(input);
				}}catch (Exception e) {
					e.printStackTrace();
				}
			return "Done ";
					

				}
		
		
		
	};
	Future<String> future=executorService.submit(callable);
	
	

			
	
}
