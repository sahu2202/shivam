package capgemin_LabBook_Lab11;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Lab11_1 extends TimerTask implements Executor {
	@Override
	public void execute(Runnable command) {
		run();
		
	}

	@Override
	public void run() {
		System.out.println("Task Started"+ new Date());
		completeTask();
		System.out.println("Task Ended"+ new Date());
	}
	public static void completeTask(){
		try{
			Thread.sleep(1000);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		TimerTask timerTask=new Lab11_1();
		Timer timer=new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 10*1000);
		System.out.println("TimerTask started");
		ExecutorService executorService=Executors.newSingleThreadExecutor();
		Callable<String> cal=new Callable<String>() {
			
			@Override
			public String call() throws Exception {
				
				return null;
			}
		};
        //cancel after sometime
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        timer.cancel();
        System.out.println("TimerTask cancelled");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
		
		Future<String> future=executorService.submit(cal);
		String str="Future Object";
		try {
			str = future.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(str);
		

	}

	
}

	


